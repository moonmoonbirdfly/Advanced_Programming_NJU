#include "shop.h"
#include "QDebug"

shop::shop() {
    sunnum = 2000;
    counter = 0;
    time = int(7.0 * 1000 / 33);
    createCards();
}

void shop::createCards() {
    card *car = nullptr;
    for (int i = 0; i < card::name.size(); ++i) {
        car = new card(card::name[i]);
        car->setParentItem(this);
        car->setPos(-157 + 65 * i, -2);
    }
}

QRectF shop::boundingRect() const {
    return QRectF(-270, -45, 540, 90);
}

void shop::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) {
    Q_UNUSED(option)
    Q_UNUSED(widget)
    painter->drawPixmap(QRect(-270, -45, 540, 90), QPixmap(":/Screen/res/Screen/Shop.png"));
    QFont font;
    font.setPointSizeF(15);
    painter->setFont(font);
    painter->drawText(QRectF(-255, 18, 65, 22), Qt::AlignCenter, QString::number(sunnum));
}

void shop::advance(int phase) {
    if (!phase)
        return;
    update();
    if (++counter >= time) {
        counter = 0;
        // scene()->addItem(new sun);
    }
}

void shop::addPlant(QString s, QPointF pos) {
    if (!canPlacePlant(pos))
        return;

    int plantCost = card::cost[card::map[s]]; // Get the cost of the plant
    if (sunnum < plantCost) {
        qDebug() << "Cannot place plant: Insufficient sunlight.";
        return;
    }

    sunnum -= plantCost;

    plant* pl = createPlant(s);
    if (pl) {
        pl->setPos(pos);
        scene()->addItem(pl);
    }

    QList<QGraphicsItem *> child = childItems();
    foreach (QGraphicsItem *item, child) {
        card *car = qgraphicsitem_cast<card *>(item);
        if (car->text == s) {
            car->counter = 0;
            break;
        }
    }

    counter = 0;
}

bool shop::canPlacePlant(QPointF pos) {
    QList<QGraphicsItem *> items = scene()->items(pos);
    foreach (QGraphicsItem *item, items) {
        if (item->type() == plant::Type) {
            qDebug() << "Cannot place plant: Another plant is already present at the location.";
            return false;
        }
    }
    return true;
}

plant* shop::createPlant(QString s) {
    plant* pl = nullptr;
    switch (card::map[s]) {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4: // SnowPea
        pl = new pea;// Handle SnowPea creation if needed
        break;
    case 5: // PotatoMine

    case 6:
        pl = new PotatoMine;
        break;
    default:
        qDebug() << "Invalid plant type.";
        break;
    }
    return pl;
}
