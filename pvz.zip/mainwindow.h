#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QMainWindow>
#include <QTimer>
#include <QWidget>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsSceneDragDropEvent>
#include <QGraphicsItem>
#include <QLineEdit>
#include <QSpinBox>
#include <QPushButton>
#include <QMessageBox>
#include <QUrl>
#include <QLabel> // 添加 QLabel
#include"plant.h"
#include"zombie.h"
namespace Ui {
class MainWindow;
}
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    enum Affix {
        None,
        Rage,
        Ice,
        AoE, // Area of Effect
        Bleed
    };
    int row;
    int SpeedCount;
    int FlashCount;
    int plantCount;
    QTimer* mQTimer;
    QGraphicsScene* scene;
    QGraphicsView* view;
    QPainter* mpainter_1;
    //class QMediaPlayer;
    QMediaPlayer *player;
    QAudioOutput * audioOutput ;
    void InitScene();
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void addZombie();
    void checkPlantDied();
    void readPlantsFromJson();
    plant* createPlant(const QString& type);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void updateAffixCount(Affix affix);
    QString PlantAffix2String(plant::Affix affix);
    QString ZombieAffix2String(zombie::Affix affix);
    void zombieDied(Affix affix);
    void exportToFile(const QString& filename);
    zombie* createZombie(const QString& type);
    QLabel *rageLabel;
    QLabel *iceLabel;
    QLabel *aoeLabel;
    QLabel *bleedLabel;

private:
    bool dragover;
    int rageCount;
    int iceCount;
    int aoeCount;
    int bleedCount;
    QLineEdit* coordinateInput; // 坐标输入框
    QSpinBox* affixInput; // 属性输入框
    QPushButton* confirmButton; // 确认按钮
    QPushButton* deleteButton;
    Affix parseAffix(const QString& affixStr);
    Ui::MainWindow *ui;
public slots:
    void onExportButtonClicked();
    void onConfirmButtonClicked();
    void onDeleteButtonClicked();
};
#endif // MAINWINDOW_H
