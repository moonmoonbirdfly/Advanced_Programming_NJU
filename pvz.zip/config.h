#ifndef CONFIG_H
#define CONFIG_H

#define GAME_LENGTH  1500  //宽度
#define GAME_HEIGHT 630  //高度
#define GAME_TITLE "PVZ" //标题
#define GAME_RATE  10
#define MAP_PATH  ":/Map/res/Map/map0.jpg" //地图图片路径
#define ZOMBIE_PATH  ":/Zombies/res/Zombies/Zombie/0.gif" //地图图片路径
#define ZOMBIE_NUM   20
#define ZOMBIE_SPEED 5
#endif // CONFIG_H
