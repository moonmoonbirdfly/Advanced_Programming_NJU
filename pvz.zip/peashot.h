#ifndef PEASHOT_H
#define PEASHOT_H
#include "other.h"

class peashot : public other
{
public:
    peashot(int attack = 0, bool flag = false,bool Bleed = false, int dir = 0,qreal x=0,qreal y=0); // Constructor to create a pea object, attack represents the attack power, flag represents whether it has a freezing effect, default to 0 and false
    QRectF boundingRect() const override; // Return the bounding rectangle of the pea for collision detection
    bool collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode) const override; // Determine whether the pea collides with other graphics items
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override; // Draw the appearance of the pea shooter
    void advance(int phase) override; // Control the movement and attack logic of the pea
private:
    qreal shoot_x;
    qreal shoot_y;
    qreal speed; // Speed of the pea (pixels moved per second)
    bool snow; // Flag indicating whether the pea has a freezing effect
    bool isBleed;
    int atk; // Attack power of the pea
    int direction; // Direction of movement, 1 for down, -1 for up
};

#endif // PEASHOT_H
