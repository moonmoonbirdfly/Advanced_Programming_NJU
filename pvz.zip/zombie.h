#ifndef ZOMBIE_H
#define ZOMBIE_H

#include <QGraphicsItem>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QPainter>
#include <QMovie>
#include <QObject>
#include <QElapsedTimer>

class zombie : public QObject, public QGraphicsItem
{
    Q_OBJECT
public:
    enum { Type = UserType + 2 };
    enum Affix {
        None,
        Flash, //闪现
        Speed  //神速
    };

    Affix m_affix1;
    Affix m_affix2;
    int hp;
    int maxHp; // Add maxHp to define the maximum health of the zombie
    int state;
    int atk;
    int FrozenCounter;
    int FrozenTime;
    int totalBleedAmount; // 在两秒内总共需要失去的血量
    int bleedRate; // 每次更新时失血的量
    QElapsedTimer bleedTimer; // 用于跟踪上次失血的时间
    bool isFrozen;
    bool isBleed;
    qreal speed;
    qreal basic_speed;
    QMovie* mQMovie;
    QMovie* mhead;

    QElapsedTimer flashCooldownTimer; // Timer for flash ability cooldown
    const int flashCooldownTime = 1000; // 5 seconds cooldown

    zombie();
    ~zombie();
    Affix parseAffix(const QString& affixStr);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget) override;
    QRectF boundingRect() const override;
    bool collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode) const override;
    void setMovie(QString path);
    void setHead(QString path);
    int type() const override;
    void setExplosionAnimation();
    virtual void drawHealthBar(QPainter *painter); // Add a method to draw the health bar
signals:
    void died();
};

#endif // ZOMBIE_H
