#include "plant.h"
#include "zombie.h"

plant::plant()
{   m_affix1 = None;m_affix2 = None;
    maxHp=hp=state=atk=original_atk=counter=time=0;
    plantType="None";
    mQMovie=nullptr;
}

plant::~plant()
{
    delete mQMovie;
}
void plant::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option);
    Q_UNUSED(widget);
    //qDebug()<<1234;

    // 绘制植物的图像
    painter->drawImage(boundingRect(), mQMovie->currentImage());
    drawHealthBar(painter);
    // 设置字体和颜色
    QFont font("Arial", 10, QFont::Bold);
    painter->setFont(font);
    painter->setPen(Qt::black);

    // 计算文本位置
    int textYOffset =0; // 使文本在植物上方显示
    QRectF rect = boundingRect();
    QPointF textPos(rect.center().x(), rect.top() + textYOffset);

    // 显示 m_affix1
    if (m_affix1 != None) {
        QString affix1Text;
        switch (m_affix1) {
        case Rage: affix1Text = "Rage"; break;
        case Ice: affix1Text = "Ice"; break;
        case AoE: affix1Text = "AoE"; break;
        case Bleed: affix1Text = "Bleed"; break;
        default: break;
        }
        painter->drawText(textPos, affix1Text);
        textPos.setY(textPos.y() + 15); // 移动到下一个文本位置
    }

    // 显示 m_affix2
    if (m_affix2 != None) {
        QString affix2Text;
        switch (m_affix2) {
        case Rage: affix2Text = "Rage"; break;
        case Ice: affix2Text = "Ice"; break;
        case AoE: affix2Text = "AoE"; break;
        case Bleed: affix2Text = "Bleed"; break;
        default: break;
        }
        painter->drawText(textPos, affix2Text);
    }


}


plant::Affix plant::parseAffix(const QString& affixStr)
{
    if (affixStr == "Rage") {
        return Rage;
    } else if (affixStr == "Ice") {
        return Ice;
    } else if (affixStr == "AoE") {
        return AoE;
    } else if (affixStr == "Bleed") {
        return Bleed;
    } else {
        return None;
    }
}
void plant::setMovie(QString path)
{
    if(mQMovie)
        delete mQMovie;
    mQMovie=new QMovie(path);
    mQMovie->start();
}
QRectF plant::boundingRect()const
{
    return QRect(-35,-35,70,70);
}
bool plant::collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode)const
{
    Q_UNUSED(mode);

    return other->type() == zombie::Type && qFuzzyCompare(other->y(), y()) && qAbs(other->x() - x()) < 30;

}
int plant::type()const
{
    return Type;
}
void plant::drawHealthBar(QPainter *painter)
{
    if (maxHp <= 0)
        return;
    int barWidth = 50;
    int barHeight = 10;
    int barX = -20;
    int barY = -50;

    double healthPercentage = static_cast<double>(hp) / maxHp;
    if(hp<=0) {healthPercentage=0;hp=0;}
    int healthBarWidth = static_cast<int>(barWidth * healthPercentage);

    // Draw the background of the health bar
    painter->setBrush(Qt::red);
    painter->drawRect(barX, barY, barWidth, barHeight);
    // Draw the foreground of the health bar
    painter->setBrush(Qt::green);
    painter->drawRect(barX, barY, healthBarWidth, barHeight);
}
