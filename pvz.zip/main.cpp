#include "mainwindow.h"

#include <QApplication>
#include <QLocale>
#include <QTranslator>
//#include "gamestart.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //GameStart s;
    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "pvz_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            a.installTranslator(&translator);
            break;
        }
    }

    //if (s.exec()==QDialog::Accepted)
    //{
    MainWindow w;
    w.show();
    return a.exec();
    //}else return 0;
}
