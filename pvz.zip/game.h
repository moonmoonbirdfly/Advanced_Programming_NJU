#ifndef GAME_H
#define GAME_H
#include <QWidget>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QTimer>

class game : public QWidget
{
    Q_OBJECT
public:

    QTimer* mQTimer;
    QGraphicsView* view;
    QGraphicsScene* scene;
    game();
    ~game();


};

#endif // GAME_H
