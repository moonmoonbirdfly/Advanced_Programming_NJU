#include "basiczombie.h"
#include <QGraphicsScene>
#include <QGraphicsItem>
#include "plant.h"

basiczombie::basiczombie()
{
    maxHp = hp = 200; // 设置基础僵尸的生命值为200
    atk = 100 * 33 / 1000; // 设置基础僵尸的攻击力为100（每秒攻击100点）
    basic_speed = speed = 5.0 * 33 / 1000; // 设置基础僵尸的速度为5.0像素/秒（33毫秒为帧间隔）
    FrozenCounter = 0;
    FrozenTime = int(0.7 * 1000 / 33);
    isFrozen = false;
    isBleed = false;
    setMovie(":/Zombies/res/Zombies/Zombie/Zombie1.gif"); // 设置基础僵尸的行走动画

    // Adjust speed if the zombie has the Speed affix

}

void basiczombie::advance(int phase)
{
    if (!phase)
        return;

    if (isFrozen && state != 2) {
        if (++FrozenCounter >= FrozenTime) {
            FrozenCounter = 0;
            isFrozen = false;
        }
        if (hp > 0) return;
    } else {
        FrozenCounter = 0;
    }
    if (m_affix1 == Speed || m_affix2 == Speed) {
        if(speed<=basic_speed)speed *= 1.5; // Increase speed by 50%
    }
    if (isBleed && bleedTimer.elapsed() < 2000) { // 两秒内
        hp -= bleedRate; // 扣除血量
        if (hp <= 0) hp = 0; // 确保血量不会变成负数
        if (bleedTimer.elapsed() >= 2000) { // 如果两秒已经过去
            isBleed = false; // 停止失血
            bleedTimer.invalidate(); // 停止计时器
        }
    }

    if (isBleed && bleedTimer.elapsed() >= 2000) {
        isBleed = false;
        bleedTimer.invalidate();
    }

    update();

    if (hp <= 0) // 如果基础僵尸的生命值小于等于0，表示已经被击败
    {
        if (state < 2) // 如果基础僵尸的状态小于2，表示处于行走状态
        {
            state = 2; // 将状态设置为2（死亡）
            emit died();
            setMovie(":/Zombies/res/Zombies/Zombie/ZombieDie.gif"); // 设置基础僵尸的死亡动画
            setHead(":/Zombies/res/Zombies/Zombie/ZombieHead.gif"); // 设置基础僵尸的头部掉落动画
        }
        else if (mQMovie->currentFrameNumber() == mQMovie->frameCount() - 1)
            delete this; // 如果基础僵尸的死亡动画播放完毕，删除基础僵尸对象
        return;
    }

    QList<QGraphicsItem *> items = collidingItems();

    if (!items.isEmpty() && !isFrozen) // 如果基础僵尸与其他图形项发生碰撞
    {
        plant *pl = qgraphicsitem_cast<plant *>(items[0]);
        if (m_affix1 == Flash || m_affix2 == Flash) {
            if(!flashCooldownTimer.isValid())flashCooldownTimer.start();
            //qDebug()<<flashCooldownTimer.isValid();
            if (flashCooldownTimer.elapsed() >= flashCooldownTime&&flashCooldownTimer.isValid()) {
                // Flash over the plant
                qDebug()<<"flash in";
                setX(x() - 85); // Move zombie ahead by 50 pixels
                flashCooldownTimer.restart();
            } else {
                pl->hp -= atk; // 减少植物的生命值，受到基础僵尸的攻击
            }
        } else {
            pl->hp -= atk; // 减少植物的生命值，受到基础僵尸的攻击
        }

        if (state != 1) // 如果基础僵尸的状态不为1（攻击状态）
        {
            state = 1; // 将状态设置为1（攻击）
            setMovie(":/Zombies/res/Zombies/Zombie/ZombieAttack.gif"); // 设置基础僵尸的攻击动画
        }
        return;
    }

    if (state) // 如果基础僵尸的状态不为0（行走状态）
    {
        state = 0; // 将状态设置为0（行走）
        setMovie(":/Zombies/res/Zombies/Zombie/Zombie1.gif"); // 设置基础僵尸的行走动画
    }

    setX(x() - speed); // 更新基础僵尸的位置，让其向左移动
}
