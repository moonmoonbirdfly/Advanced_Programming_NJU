#include "pea.h"
#include "zombie.h"
#include "peashot.h"

pea::pea()
{
    maxHp = hp = 200; // Set the health of the pea shooter to 200
    atk = 25; // Set the attack power of the pea shooter to 25
    original_atk = 25;
    time = int(1.4 * 1000 / 33); // Calculate the attack interval of the pea shooter in frames, 1.4 seconds corresponding to the number of frames (33 milliseconds per frame interval)
    setMovie(":/Plants/res/Plants/Peashooter/1.gif"); // Set the animation of the pea shooter
    plantType = "peashooter";
}

void pea::advance(int phase)
{
    if (!phase)
        return;
    update(); // Update the drawing of the pea shooter

    if (hp <= 0) {
        emit died();
        delete this;
        return; // Don't forget to return here after deleting this object
    }
    else if (++counter >= time) // Every attack interval frame
    {
        counter = 0; // Reset the counter
        QList<QGraphicsItem *> items = collidingItems();
        zombie *closestZombie = nullptr;
        qreal closestDistance = std::numeric_limits<qreal>::max();

        for (QGraphicsItem *item : items)
        {
            if (zombie *zom = qgraphicsitem_cast<zombie *>(item))
            {
                // Calculate the distance to the zombie
                qreal distance = qAbs(zom->x() - x());
                // Check if the zombie is in an adjacent row (±1 row)
                if (qAbs(zom->y() - y()) <= 100 && !qFuzzyCompare(zom->y(), y()))
                {
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestZombie = zom;
                    }
                }
            }
        }

        if (closestZombie)
        {
            peashot *newshot = nullptr;
            // Create a new peashot object with diagonal movement
            if (m_affix1 == Ice || m_affix2 == Ice) {
                if (m_affix1 == Bleed || m_affix2 == Bleed)
                    newshot = new peashot(atk, true, true, closestZombie->y() > y() ? 1 : -1, closestZombie->x(), closestZombie->y());
                else
                    newshot = new peashot(atk, true, false, closestZombie->y() > y() ? 1 : -1, closestZombie->x(), closestZombie->y());
            }
            else {
                if (m_affix1 == Bleed || m_affix2 == Bleed)
                    newshot = new peashot(atk, false, true, closestZombie->y() > y() ? 1 : -1, closestZombie->x(), closestZombie->y());
                else
                    newshot = new peashot(atk, false, false, closestZombie->y() > y() ? 1 : -1, closestZombie->x(), closestZombie->y());
            }

            newshot->setX(x() + 30); // Set the initial position of the bullet 30 pixels to the right of the pea shooter
            newshot->setY(y()); // Set the height of the bullet to the same as the pea shooter
            scene()->addItem(newshot); // Add the bullet to the scene
            return; // Return without moving
        }
    }

    switch (m_affix1) {
    case None:
        break;
    case Bleed:
        break;
    case Rage:
        atk *= 2;
        time = int(0.7 * 1000 / 33);
        break;
    case Ice:
        atk = original_atk;
        time = int(1.4 * 1000 / 33);
        break;
    case AoE:
        m_affix1 = None;
        atk = original_atk;
        time = int(1.4 * 1000 / 33);
        break;
    }

    switch (m_affix2) {
    case None:
        break;
    case Bleed:
        break;
    case Rage:
        atk *= 2;
        time = int(0.7 * 1000 / 33);
        break;
    case Ice:
        atk = original_atk;
        time = int(1.4 * 1000 / 33);
        break;
    case AoE:
        m_affix2 = None;
        atk = original_atk;
        time = int(1.4 * 1000 / 33);
        break;
    }

    if (m_affix1 == None && m_affix2 == None) {
        atk = original_atk;
        time = int(1.4 * 1000 / 33);
    }
    else if (m_affix1 != Rage && m_affix2 != Rage) {
        atk = original_atk;
        time = int(1.4 * 1000 / 33);
    }
}

bool pea::collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode) const
{
    Q_UNUSED(mode)
    // Ignore collisions in the same row
    return other->type() == zombie::Type && qAbs(other->y() - y()) <= 100 && !qFuzzyCompare(other->y(), y()) && other->x()>x()+5;
}
