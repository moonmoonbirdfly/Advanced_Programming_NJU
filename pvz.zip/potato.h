#ifndef POTATO_H
#define POTATO_H

#include "plant.h"
#include <QGraphicsItem>
#include <QList>

class PotatoMine : public plant
{
public:
    PotatoMine();
    void advance(int phase) override;
    bool collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode) const override;

private:
    void explode();
    void resetToNormalState();

    int explodeRange;
    int original_explodeRange;
    int counter;
    bool exploding; // 标记土豆地雷是否在爆炸状态
    int explodeCounter; // 用于记录爆炸动画播放的时间
};

#endif // POTATO_H
