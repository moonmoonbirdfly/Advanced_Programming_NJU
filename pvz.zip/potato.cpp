#include "potato.h"
#include "zombie.h"

PotatoMine::PotatoMine()
    : plant(), exploding(false), explodeCounter(0)
{
    maxHp = hp = 200; // 设置土豆地雷的生命值
    atk = 50; // 设置土豆地雷的攻击力
    original_atk = atk;
    explodeRange = 85; // 设置爆炸范围
    original_explodeRange = explodeRange;
    exploding=false;
    explodeCounter=0;
    time = int(1.4 * 1000 / 33);
    m_affix1=None;
    m_affix2=None;
    plantType="potatomine";
    setMovie(":/Plants/res/Plants/PotatoMine/PotatoMine.gif"); // 设置土豆地雷的动画
}

void PotatoMine::advance(int phase)
{
    if (!phase)
        return;

    update(); // 更新土豆地雷的绘制
    //rage ice aoe
    switch(m_affix1){
    case None:
        break;
    case Bleed:
        m_affix1=None;break;
    case Rage:
        atk*=2;
        time=int(0.7 * 1000 / 33);;
        break;
    case Ice:
        atk=original_atk;
        time= int(1.4 * 1000 / 33);
        break;
    case AoE:
        explodeRange = 1200;
        atk=original_atk;
        time= int(1.4 * 1000 / 33);
        break;
    }

    switch(m_affix2){
    case None:
        break;
    case Bleed:
        m_affix2=None;break;
    case Rage:
        atk*=2;
        time=int(0.7 * 1000 / 33);;
        break;
    case Ice:
        atk=original_atk;
        time= int(1.4 * 1000 / 33);
        break;
    case AoE:
        explodeRange = 1200;
        atk=original_atk;
        time= int(1.4 * 1000 / 33);
        break;
    }

    if(m_affix1==None&&m_affix2==None){
        atk=original_atk;
        time= int(1.4 * 1000 / 33);
    }
    else if(m_affix1!=Rage&&m_affix2!=Rage){
        atk=original_atk;
        time= int(1.4 * 1000 / 33);
    }
    if(m_affix1!=AoE&&m_affix2!=AoE){
        explodeRange = original_explodeRange;
    }
    if (hp <= 0)
    {
        emit died();
        delete this;
    }
    else if (exploding)
    {
        // 爆炸动画播放
        if (++explodeCounter >= 5) // 假设爆炸动画播放30帧后恢复
        {
            resetToNormalState();
        }
    }
    else if (++counter >= time) // 每次攻击间隔
    {
        counter = 0;
        QList<QGraphicsItem *> items = collidingItems();
        for (QGraphicsItem *item : items)
        {
            if (zombie *zom = qgraphicsitem_cast<zombie *>(item))
            {
                // 检查僵尸是否在土豆地雷右侧且距离小于爆炸范围
                if (zom->x() - x() >= 0 && zom->x() - x() <= explodeRange && qFuzzyCompare(zom->y(), y()))
                {
                    explode(); // 触发爆炸
                    return;
                }
            }
        }
    }
}

bool PotatoMine::collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode) const
{
    Q_UNUSED(mode)
    // 仅当僵尸在土豆地雷右侧且距离小于爆炸范围时触发
    return other->type() == zombie::Type && (other->x() - x() > 0) && (other->x() - x() <= explodeRange) && qFuzzyCompare(other->y(), y());
}

void PotatoMine::explode()
{
    QList<QGraphicsItem *> items = collidingItems();
    if (!items.isEmpty())
    {
        bool aoe = (m_affix1 == AoE || m_affix2 == AoE);
        QGraphicsItem *closestZombie = nullptr;
        qreal closestDistance = std::numeric_limits<qreal>::max();

        for (QGraphicsItem *item : items)
        {
            if (zombie *zom = qgraphicsitem_cast<zombie *>(item))
            {
                qreal distance = qAbs(zom->x() - x());
                if (aoe || (zom->x() - x() >= 0 && (int)distance <= explodeRange && qFuzzyCompare(zom->y(), y())))
                {
                    qDebug()<<"aoe";
                    if (aoe)
                    {
                        zom->hp -= atk; // 对僵尸造成伤害
                        if (m_affix1 == Ice || m_affix2 == Ice)
                        {
                            zom->isFrozen = true;
                        }

                        // 创建爆炸动画对象
                        QGraphicsPixmapItem *explosion = new QGraphicsPixmapItem(QPixmap(":/Plants/res/Plants/PotatoMine/PotatoMine_mashed.gif"));
                        explosion->setScale(0.5);
                        explosion->setPos(QPoint(zom->x(), zom->y())); // 设置爆炸动画的位置与僵尸位置一致
                        scene()->addItem(explosion); // 将爆炸动画添加到场景中

                        // 设置定时器，一段时间后移除爆炸动画
                        QTimer::singleShot(1000, [explosion](){
                            explosion->scene()->removeItem(explosion);
                            delete explosion;
                        });
                    }
                    else if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestZombie = item;
                    }
                }
            }
        }

        if (!aoe && closestZombie)
        {
            if (zombie *zom = qgraphicsitem_cast<zombie *>(closestZombie))
            {
                zom->hp -= atk; // 对僵尸造成伤害
                if (m_affix1 == Ice || m_affix2 == Ice)
                {
                    zom->isFrozen = true;
                }

                // 创建爆炸动画对象
                QGraphicsPixmapItem *explosion = new QGraphicsPixmapItem(QPixmap(":/Plants/res/Plants/PotatoMine/PotatoMine_mashed.gif"));
                explosion->setScale(0.5);
                explosion->setPos(QPoint(zom->x(), zom->y())); // 设置爆炸动画的位置与僵尸位置一致
                scene()->addItem(explosion); // 将爆炸动画添加到场景中

                // 设置定时器，一段时间后移除爆炸动画
                QTimer::singleShot(1000, [explosion](){
                    explosion->scene()->removeItem(explosion);
                    delete explosion;
                });
            }
        }

        // 设置土豆地雷状态为爆炸状态
        exploding = true;
        explodeCounter = 0;
    }
}




void PotatoMine::resetToNormalState()
{
    setMovie(":/Plants/res/Plants/PotatoMine/PotatoMine.gif");
    exploding = false;
}
