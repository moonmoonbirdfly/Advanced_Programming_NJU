#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "config.h"
#include "basiczombie.h"
#include <bits/stdc++.h>
#include "plant.h"
#include "pea.h"
#include "shop.h"
#include "map.h"
#include <QGraphicsSceneDragDropEvent>
#include <QGraphicsItem>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QVBoxLayout>
#include <QHBoxLayout>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , rageCount(0)
    , iceCount(0)
    , aoeCount(0)
    , bleedCount(0)
    , SpeedCount(0)
    , FlashCount(0)
    , plantCount(0)
    , row(0)
{
    mQTimer = new QTimer(this);
    player = new QMediaPlayer;
    audioOutput = new QAudioOutput;
    player->setAudioOutput(audioOutput);
    player->setSource(QUrl("qrc:/Sound/res/Sound/Grazy.wav"));
    audioOutput->setVolume(50);
    player->play();

    scene = new QGraphicsScene(this);
    scene->setSceneRect(150, 0, 900, 600); // 控制 img 需要截取部分
    scene->setItemIndexMethod(QGraphicsScene::NoIndex);

    shop *sh = new shop;
    sh->setPos(520, 45);
    scene->addItem(sh);

    coordinateInput = new QLineEdit(this);
    coordinateInput->setPlaceholderText("Enter coordinate:x,y");

    affixInput = new QSpinBox(this);
    affixInput->setRange(1, 4); // 设置属性范围

    confirmButton = new QPushButton("Confirm", this);
    deleteButton = new QPushButton("Delete", this);
    connect(confirmButton, &QPushButton::clicked, this, &MainWindow::onConfirmButtonClicked);
    connect(deleteButton, &QPushButton::clicked, this, &MainWindow::onDeleteButtonClicked);

    Map *map = new Map;
    map->setPos(618, 326);
    scene->addItem(map);

    setMinimumSize(910, 600);

    view = new QGraphicsView(scene, this);  // 初始化 view 成员
    view->resize(900, 600);
    view->setRenderHint(QPainter::Antialiasing);
    view->setBackgroundBrush(QPixmap(":/Map/res/Map/map0.jpg")); // 设置背景图片
    view->setCacheMode(QGraphicsView::CacheBackground);
    view->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
    view->setMinimumSize(900, 600);
    view->setAcceptDrops(true);
    setAcceptDrops(true); // Ensure MainWindow accepts drops

    rageLabel = new QLabel("Rage: 0", this);
    iceLabel = new QLabel("Ice: 0", this);
    aoeLabel = new QLabel("AoE: 0", this);
    bleedLabel = new QLabel("Bleed: 0", this);
    QPushButton *exportButton = new QPushButton("Export", this);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::onExportButtonClicked);

    // 去除标签的外边距
    rageLabel->setContentsMargins(0, 0, 0, 0);
    iceLabel->setContentsMargins(0, 0, 0, 0);
    aoeLabel->setContentsMargins(0, 0, 0, 0);
    bleedLabel->setContentsMargins(0, 0, 0, 0);

    QVBoxLayout *labelsLayout = new QVBoxLayout();
    labelsLayout->setSpacing(0);
    labelsLayout->addWidget(rageLabel);
    labelsLayout->addWidget(iceLabel);
    labelsLayout->addWidget(aoeLabel);
    labelsLayout->addWidget(bleedLabel);
    labelsLayout->addWidget(exportButton);


    QHBoxLayout *inputLayout = new QHBoxLayout();
    inputLayout->addWidget(coordinateInput);
    inputLayout->addWidget(affixInput);
    inputLayout->addWidget(confirmButton);
    inputLayout->addWidget(deleteButton);
    inputLayout->setSpacing(10); // 设置控件之间的间距

    QVBoxLayout *leftLayout = new QVBoxLayout(); // 用于包含labels和输入框的左侧布局
    leftLayout->addLayout(labelsLayout);
    leftLayout->addLayout(inputLayout);
    leftLayout->setSpacing(10); // 设置两个子布局之间的间距

    QHBoxLayout *mainLayout = new QHBoxLayout();
    mainLayout->addLayout(leftLayout);
    mainLayout->addWidget(view);
    mainLayout->setSpacing(15); // 设置控件之间的间距
    mainLayout->setContentsMargins(10, 10, 10, 10); // 设置布局的外边距

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    connect(mQTimer, &QTimer::timeout, scene, &QGraphicsScene::advance);

    connect(mQTimer, &QTimer::timeout, this, &MainWindow::checkPlantDied);
    connect(mQTimer, &QTimer::timeout, this, &MainWindow::addZombie);
    mQTimer->start(33); // 启动计时器，每33毫秒触发一次 timeout 信号，驱动游戏动画效果
    view->show(); // 显示视图

    readPlantsFromJson();

}


void MainWindow::checkPlantDied(){
    static int maxtime2 = 20 * 500 / 33;
    static int time2 = maxtime2 / 10;
    static int counter2 = 0;
    static bool death=false;
    if (++counter2 >= time2){
        counter2=0;
        death=false;
    foreach (QGraphicsItem *item, scene->items()) {
        if (plant* p = qgraphicsitem_cast<plant*>(item)) {
            // 这里确保信号连接只在植物第一次死亡时执行
            if(!death) {connect(p, &plant::died, this, [this]() {
                // Randomly choose an affix to drop
                    qDebug() << "plant::died signal"<<death;
                zombie::Affix affix = static_cast<zombie::Affix>(rand() % 2+1);
                //zombieDied(affix);
                if(!death)death=true;
                if(death){
                    switch(affix){
                    case zombie::Speed:
                        SpeedCount++;
                        break;
                    case zombie::Flash:
                        FlashCount++;
                        break;
                    default:break;
                    }
                }
                });death=true;}
            //qDebug() << SpeedCount<<FlashCount;
            if(SpeedCount<0) SpeedCount=0;
            if(FlashCount<0) FlashCount=0;
            if(SpeedCount>=1||FlashCount>=1){
                bool attributeAdded = false; // 添加标志位
                foreach (QGraphicsItem *item2, scene->items()){
                    if (zombie* zom = qgraphicsitem_cast<zombie*>(item2)){
                        if(zom->m_affix1!=zombie::None&&zom->m_affix2!=zombie::None) continue;
                        if(SpeedCount>=1 && !attributeAdded){
                            zombie::Affix affixType=zombie::Speed;
                            if(zom->m_affix1==zombie::Affix(None)){
                                zom->m_affix1=affixType;
                                SpeedCount--;
                                attributeAdded = true; // 标记属性已增加
                                //death=false;
                            }else if(zom->m_affix2==zombie::Affix(None)&& zom->m_affix1!=affixType){
                                zom->m_affix2=affixType;
                                SpeedCount--;
                                attributeAdded = true; // 标记属性已增加
                                //death=false;
                            }
                        }else if(FlashCount>=1 && !attributeAdded){
                            zombie::Affix affixType=zombie::Flash;
                            if(zom->m_affix1==zombie::Affix(None)){
                                zom->m_affix1=affixType;
                                FlashCount--;
                                attributeAdded = true; // 标记属性已增加
                                //death=false;
                            }else if(zom->m_affix2==zombie::Affix(None)&& zom->m_affix1!=affixType){
                                zom->m_affix2=affixType;
                                FlashCount--;
                                attributeAdded = true; // 标记属性已增加
                                //death=false;
                            }
                        }
                        if (attributeAdded) break; // 增加属性后退出循环
                    }
                }
            }//qDebug() <<"NOW"<< SpeedCount<<FlashCount;
        }
    }
    }
}

// 槽函数，处理确认按钮点击事件
void MainWindow::onConfirmButtonClicked()
{
    QString coordinateText = coordinateInput->text();
    int affix = affixInput->value();

    // 检查坐标输入框是否为空
    if (coordinateText.isEmpty()) {
        QMessageBox::warning(this, "Warning", "Coordinate input is empty!");
        return;
    }

    // 解析坐标字符串
    QStringList parts = coordinateText.split(',');
    if (parts.size() != 2) {
        QMessageBox::warning(this, "Warning", "Invalid coordinate format! Use (x,y)");
        return;
    }

    bool ok;
    int x = parts[0].toInt(&ok);
    if (!ok) {
        QMessageBox::warning(this, "Warning", "Invalid x coordinate!");
        return;
    }

    int y = parts[1].toInt(&ok);
    if (!ok) {
        QMessageBox::warning(this, "Warning", "Invalid y coordinate!");
        return;
    }

    // 在位于指定坐标的植物上增加属性
    foreach (QGraphicsItem *item, scene->items()) {
        if (plant* p = qgraphicsitem_cast<plant*>(item)) {
            //(pos.setX((int(pos.x())-245)/85 * 85 +290);
            // pos.setY((int(pos.y())-80)/95 * 95 +120);)
            //qDebug()<<p->pos().y();
            //qDebug()<<((p->pos().x()-290)/85*85+290==x*85+290)<<((int)((p->pos().y()-95)/95 * 95 +95) == y*95+120)
            //         <<((p->pos().y()-95)/95 * 95 +95)<<y*95+120;
            //std::cout<<((p->pos().y()-95)/95 * 95 +95)<<std::endl;
            //std::cout<<y*95+120<<std::endl;
                if (((int)((p->pos().x()-290)/85*85+290) == x*85+290)&& ((int)((p->pos().y()-95)/95 * 95 +95) == y*95+120)) {
                // 根据属性值设置植物属性
                    qDebug()<<"qq"<<(p->pos().x()-290)/85*85+290<<x*85+290<<(p->pos().y()-95)/95 * 95 +95<<y*95+120;

                plant::Affix affixType = static_cast<plant::Affix>(affix);
                int count0=0;
                switch (affixType) {
                case plant::None:
                    count0=0;
                    break;
                case plant::Rage:
                    count0=rageCount;
                    break;
                case plant::Ice:
                    count0=iceCount;
                    break;
                case plant::AoE:
                    count0=aoeCount;
                    break;
                case plant::Bleed:
                    count0=bleedCount;
                    break;
                default:
                    break;
                }
                qDebug()<<"count0"<<count0;
                if(count0){
                    if(p->plantType=="peashooter"&&affixType==plant::AoE) break;
                    if(p->plantType=="potatomine"&&affixType==plant::Bleed) break;//rage ice aoe
                    if(p->m_affix1==affixType||p->m_affix2==affixType) break;
                    if(p->m_affix1==plant::Affix(None)){
                        p->m_affix1=affixType;
                    }else if(p->m_affix2==plant::Affix(None)&& p->m_affix1!=affixType){
                        p->m_affix2=affixType;
                    }else if(p->m_affix2!=affixType){
                        p->m_affix1=affixType;
                    }
                    switch (affixType) {
                    case plant::None:
                        count0=0;
                        break;
                    case plant::Rage:
                        count0--;
                        (--rageCount)--;
                        updateAffixCount(Rage);
                        break;
                    case plant::Ice:
                        count0--;
                        (--iceCount)--;
                        updateAffixCount(Ice);
                        break;
                    case plant::AoE:
                        count0--;
                        (--aoeCount)--;
                        updateAffixCount(AoE);
                        break;
                    case plant::Bleed:
                        count0--;
                        (--bleedCount)--;
                        updateAffixCount(Bleed);
                        break;
                    default:
                        break;
                    }qDebug()<<"count0 new"<<count0;
                }
                break;
            }
        }
    }
}


void MainWindow::onDeleteButtonClicked()
{
    QString coordinateText = coordinateInput->text();
    int affix = affixInput->value();

    // 检查坐标输入框是否为空
    if (coordinateText.isEmpty()) {
        QMessageBox::warning(this, "Warning", "Coordinate input is empty!");
        return;
    }
    // 解析坐标字符串
    QStringList parts = coordinateText.split(',');
    if (parts.size() != 2) {
        QMessageBox::warning(this, "Warning", "Invalid coordinate format! Use (x,y)");
        return;
    }
    bool ok;
    int x = parts[0].toInt(&ok);
    if (!ok) {
        QMessageBox::warning(this, "Warning", "Invalid x coordinate!");
        return;
    }

    int y = parts[1].toInt(&ok);
    if (!ok) {
        QMessageBox::warning(this, "Warning", "Invalid y coordinate!");
        return;
    }

    // 在位于指定坐标的植物上增加属性
    foreach (QGraphicsItem *item, scene->items()) {
        if (plant* p = qgraphicsitem_cast<plant*>(item)) {
            //(pos.setX((int(pos.x())-245)/85 * 85 +290);
            // pos.setY((int(pos.y())-80)/95 * 95 +120);)
            //qDebug()<<p->pos().y();
            qDebug()<<(p->pos().x()-290)/85*85+290<<x*85+290<<(p->pos().y()-95)/95 * 95 +120-25<<y*95+120;
            if (((int)((p->pos().x()-290)/85*85+290) == x*85+290)&& ((int)((p->pos().y()-95)/95 * 95 +95) == y*95+120)) {
                // 根据属性值设置植物属性
                //qDebug()<<"asdqq1";
                plant::Affix affixType = static_cast<plant::Affix>(affix);
                if(p->m_affix1==affixType){
                    p->m_affix1=plant::Affix(None);
                }else if(p->m_affix2==affixType){
                    p->m_affix2=plant::Affix(None);
                }
                break;
            }
        }
    }
}
MainWindow::Affix MainWindow::parseAffix(const QString& affixStr)
{
    if (affixStr == "Rage") {
        return Rage;
    } else if (affixStr == "Ice") {
        return Ice;
    } else if (affixStr == "AoE") {
        return AoE;
    } else if (affixStr == "Bleed") {
        return Bleed;
    } else {
        return None;
    }
}

void MainWindow::updateAffixCount(Affix affix)
{
    switch (affix)
    {
    case Rage:
        rageCount++;
        rageLabel->setText(QString("Rage: %1").arg(rageCount));
        break;
    case Ice:
        iceCount++;
        iceLabel->setText(QString("Ice: %1").arg(iceCount));
        break;
    case AoE:
        aoeCount++;
        aoeLabel->setText(QString("AoE: %1").arg(aoeCount));
        break;
    case Bleed:
        bleedCount++;
        bleedLabel->setText(QString("Bleed: %1").arg(bleedCount));
        break;
    default:
        break;
    }
    // Update the scene or UI to reflect the new counts
    //qDebug() << "Rage:" << rageCount << "Ice:" << iceCount << "AoE:" << aoeCount << "Bleed:" << bleedCount;
}
QString MainWindow::PlantAffix2String(plant::Affix affix){
    switch (affix)
    {
    case plant::Rage:
        return QString("Rage");
        break;
    case plant::Ice:
        return QString("Ice");
        break;
    case plant::AoE:
        return QString("AoE");
        break;
    case plant::Bleed:
        return QString("Bleed");
        break;
    default:
        return QString("None");
        break;
    }
}
QString MainWindow::ZombieAffix2String(zombie::Affix affix){
    switch (affix)
    {
    case zombie::Speed:
        return QString("Speed");
        break;
    case  zombie::Flash:
        return QString("Flash");
        break;
    default:
        return QString("None");
        break;
    }
}
plant* MainWindow::createPlant(const QString& type)
{
    if (type == "peashooter") {
        return new pea;
    } else if (type == "sunflower") {
        return new pea;
        //return new Sunflower();
    } else if (type == "cherrybomb") {
        return new pea;
        //return new CherryBomb();
    } else if (type == "wallnut") {
        return new pea;
        //return new WallNut();
    } else if (type == "potatomine") {
        return new PotatoMine;
        //return new PotatoMine();
    } else {
        qDebug() << "Unknown plant type:" << type;
        return nullptr;
    }
}


MainWindow::~MainWindow()
{
    player->stop();
    delete player;
    delete ui;
}
void MainWindow::readPlantsFromJson()
{
    QFile file(":/plants.json");
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this, "Warning", "Error opening plants.json");

        qDebug() << "Error opening plants.json";
        return;
    }

    QByteArray jsonData = file.readAll();
    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    QJsonObject root = doc.object();

    // Read plants information
    if (root.contains("plants") && root["plants"].isArray())
    {
        QJsonArray plantsArray = root["plants"].toArray();
        for (const QJsonValue& plantValue : plantsArray)
        {
            plantCount++;
            QJsonObject plantObject = plantValue.toObject();
            QString type = plantObject["type"].toString();
            double x = plantObject["x"].toDouble();
            double y = plantObject["y"].toDouble();
            int hp=plantObject["hp"].toInt();
            int maxhp=plantObject["maxHp"].toInt();
            QString affix1_String=plantObject["m_affix1"].toString();
            QString affix2_String=plantObject["m_affix2"].toString();
            plant* plant = createPlant(type);
            if (plant)
            {
                plant->setPos(x, y);
                plant->hp=hp;
                plant->maxHp=maxhp;
                plant->m_affix1=plant->parseAffix(affix1_String);
                plant->m_affix2=plant->parseAffix(affix2_String);
                scene->addItem(plant);
            }
        }
    }
    else
    {
        QMessageBox::warning(this, "Warning", "Invalid JSON format in plants.json");
        qDebug() << "Invalid JSON format in plants.json";
    }
    if (root.contains("row") && root["row"].isArray())
    {
        QJsonArray rowArray = root["row"].toArray();
        foreach(const QJsonValue &rowValue, rowArray)
        {
            QJsonObject rowObject = rowValue.toObject();
            row = rowObject["row"].toInt();
            if(row>=4) row=4;
            else if(row<=0) row=0;
            qDebug()<<"row="<<row;
        }
    }
    else
    {
        QMessageBox::warning(this, "Warning", "Invalid JSON format in plants.json");
        qDebug() << "Invalid JSON format in plants.json";
    }
    if(row>=4) row=4;
    // Read zombies information
    if (root.contains("zombies") && root["zombies"].isArray())
    {
        QJsonArray zombiesArray = root["zombies"].toArray();
        for (const QJsonValue& zombieValue : zombiesArray)
        {
            QJsonObject zombieObject = zombieValue.toObject();
            QString type = zombieObject["type"].toString();
            double x = zombieObject["x"].toDouble();
            double y = zombieObject["y"].toDouble();
            int hp=zombieObject["hp"].toInt();
            int maxHp=zombieObject["maxHp"].toInt();
            QString affix1_String=zombieObject["m_affix1"].toString();
            QString affix2_String=zombieObject["m_affix2"].toString();
            if(x<=0) continue;
            qDebug() << x << y<<hp<<maxHp;

            zombie* zom = createZombie(type);

            if (zom)
            {
                zom->hp=hp;
                zom->maxHp=maxHp;
                zom->setPos(x, y);
                zom->m_affix1=zom->parseAffix(affix1_String);
                zom->m_affix2=zom->parseAffix(affix2_String);
                scene->addItem(zom);
                connect(zom, &zombie::died, this, [this]() {
                    // Randomly choose an affix to drop
                    qDebug() << "zombie::died signal";
                    Affix affix = static_cast<Affix>(rand() % 4 + 1); // Randomly choose between 1 and 4
                    zombieDied(affix);
                });
            }
        }
    }
    else
    {
        QMessageBox::warning(this, "Warning", "Invalid JSON format in plants.json");
        qDebug() << "Invalid JSON format in plants.json";
    }


    if (root.contains("data") && root["data"].isArray())
    {
        QJsonArray dataArray = root["data"].toArray();
        foreach(const QJsonValue &dataValue, dataArray)
        {
            QJsonObject dataObject = dataValue.toObject();
            rageCount = dataObject["rageCount"].toInt();
            iceCount = dataObject["iceCount"].toInt();
            bleedCount = dataObject["bleedCount"].toInt();
            aoeCount = dataObject["aoeCount"].toInt();
            rageCount--;
            iceCount--;
            bleedCount--;
            aoeCount--;
            updateAffixCount(Rage);
            updateAffixCount(Ice);
            updateAffixCount(Bleed);
            updateAffixCount(AoE);
        }
    }
    else
    {
        QMessageBox::warning(this, "Warning", "Invalid JSON format in plants.json");
        qDebug() << "Invalid JSON format in plants.json";
    }

}

zombie* MainWindow::createZombie(const QString& type)
{
    if (type == "basiczombie") {
        return new basiczombie;
    } else {
        qDebug() << "Unknown zombie type:" << type;
        return nullptr;
    }
}


void MainWindow::InitScene()
{
    // 初始化场景的代码
}
void MainWindow::zombieDied(Affix affix)
{
    // Increase the count for the corresponding affix
    updateAffixCount(affix);
}
void MainWindow::addZombie()
{
    // 10秒（10000毫秒）一只僵尸，33毫秒
    static int low = 4;
    static int high = 8;
    static int maxtime = 20 * 1000 / 33;
    static int time = maxtime / 10;
    static int counter = 0;

    if (++counter >= time)
    {
        if (++low > high)
        {
            maxtime /= 1.3;
            high *= 2;
        }
        counter = 0;
        time = rand() % (2 * maxtime / 3) + maxtime / 3;
        //int type = rand() % 100;
        int i = rand() % 5;

        if(i==row) return;
        zombie *zom;
        zom = new basiczombie;
        zom->setPos(1020, 120 + 95 * i);
        scene->addItem(zom);
        connect(zom, &zombie::died, this, [this]() {
            // Randomly choose an affix to drop
            qDebug() << "zombie::died signal";
            Affix affix = static_cast<Affix>(rand() % 4 + 1); // Randomly choose between 1 and 4
            zombieDied(affix);
        });

    }

}

void MainWindow::onExportButtonClicked()
{
    QString filename = QFileDialog::getSaveFileName(this, tr("Export Scene"), QDir::currentPath(), tr("JSON Files (*.json)"));
    if (!filename.isEmpty())
    {
        exportToFile(filename);
    }
}

void MainWindow::exportToFile(const QString& filename)
{
    QJsonArray plantsArray;
    QJsonArray zombiesArray;
    QJsonArray data;
    QJsonArray rowArray;
    // Export plant and zombie information
    foreach (QGraphicsItem *item, scene->items())
    {
        if (plant* p = qgraphicsitem_cast<plant*>(item))
        {
            QJsonObject plantObject;
            plantObject["type"] = p->plantType;
            plantObject["x"] = p->pos().x();
            plantObject["y"] = p->pos().y();
            plantObject["hp"] = p->hp;
            plantObject["maxHp"] = p->maxHp;
            plantObject["m_affix1"] = PlantAffix2String(p->m_affix1);
            plantObject["m_affix2"] = PlantAffix2String(p->m_affix2);
            plantsArray.append(plantObject);
        }
        else if (zombie* z = qgraphicsitem_cast<zombie*>(item))
        {
            QJsonObject zombieObject;
            zombieObject["type"] = QString("basiczombie");
            zombieObject["x"] = z->pos().x();
            zombieObject["y"] = z->pos().y();
            zombieObject["hp"] = z->hp;
            zombieObject["maxHp"] = z->maxHp;
            zombieObject["m_affix1"]=ZombieAffix2String(z->m_affix1);
            zombieObject["m_affix2"]=ZombieAffix2String(z->m_affix2);
            zombiesArray.append(zombieObject);
        }
    }

    QJsonObject dataObject;
    dataObject["rageCount"]=rageCount;
    dataObject["iceCount"]=iceCount;
    dataObject["bleedCount"]=bleedCount;
    dataObject["aoeCount"]=aoeCount;
    data.append(dataObject);
    QJsonObject rowObject;
    rowObject["row"]=row;
    rowArray.append(rowObject);
    // Create JSON object with plants and zombies arrays
    QJsonObject rootObject;
    rootObject["data"] = data;
    rootObject["plants"] = plantsArray;
    rootObject["zombies"] = zombiesArray;
    rootObject["row"]=rowArray;

    // Convert JSON object to JSON document
    QJsonDocument doc(rootObject);
    QByteArray jsonData = doc.toJson();

    // Write JSON data to file
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly))
    {
        qDebug() << "Failed to open file for writing:" << file.errorString();
        return;
    }

    file.write(jsonData);
    file.close();
}


