#include "other.h"

other::other() {}
int other::type() const
{
    return Type;
}
