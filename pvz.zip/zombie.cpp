#include "zombie.h"
#include "plant.h"

zombie::zombie()
{
    hp = maxHp = state = atk = FrozenTime = FrozenCounter = 0; // Initialize maxHp
    basic_speed = speed = 0.0;
    m_affix1=None;
    m_affix2=None;
    bleedTimer.start(); // 开始计时
    totalBleedAmount = 20; // 设置两秒内总共失血量为20
    bleedRate = 1;
    isFrozen=isBleed=false;
    mQMovie = mhead = nullptr;
}

zombie::~zombie()
{
    delete mQMovie;
    delete mhead;
}

QRectF zombie::boundingRect() const
{
    return QRectF(-80, -100, 200, 140);
}

void zombie::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option);
    Q_UNUSED(widget);

    QImage image = mQMovie->currentImage();
    QFont font("Arial", 10, QFont::Bold);
    painter->setFont(font);
    painter->setPen(Qt::black);

    // 计算文本位置
    int textYOffset =0; // 使文本在植物上方显示
    QRectF rect = boundingRect();
    QPointF textPos(rect.center().x(), rect.top() + textYOffset);

    // 显示 m_affix1
    if (m_affix1 != None) {
        QString affix1Text;
        switch (m_affix1) {
        case Flash: affix1Text = "Flash"; break;
        case Speed: affix1Text = "Speed"; break;
        default: break;
        }
        painter->drawText(textPos, affix1Text);
        textPos.setY(textPos.y() + 15); // 移动到下一个文本位置
    }

    // 显示 m_affix2
    if (m_affix2 != None) {
        QString affix2Text;
        switch (m_affix2) {
        case Flash: affix2Text = "Flash"; break;
        case Speed: affix2Text = "Speed"; break;

        default: break;
        }
        painter->drawText(textPos, affix2Text);
    }

    //if (speed < 5.0 * 33 / 1000 && state != 3)
    if(isFrozen&& state != 3)
    {
        if (state != 2)
            mQMovie->setSpeed(50);
        int w = image.width();
        int h = image.height();
        for (int i = 0; i < h; ++i)
        {
            uchar *line = image.scanLine(i);
            for (int j = 5; j < w - 5; ++j)
                line[j << 2] = 200;
        }
    }

    painter->drawImage(QRectF(-70, -100, 140, 140), image);
    if (mhead)
    {
        image = mhead->currentImage();
        //if (speed < 5.0 * 33 / 1000)
        if(isFrozen)
        {
            int w = image.width();
            int h = image.height();

            for (int i = 0; i < h; ++i)
            {
                uchar *line = image.scanLine(i);
                for (int j = 5; j < w - 5; ++j)
                    line[j << 2] = 200;
            }
        }
        painter->drawImage(QRectF(0, -100, 140, 140), image);
    }

    drawHealthBar(painter); // Draw the health bar after drawing the zombie
}

bool zombie::collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode) const
{
    Q_UNUSED(mode)
    return other->type() == plant::Type && qFuzzyCompare(other->y(), y()) && qAbs(other->x() - x()) < 30;
}

void zombie::setMovie(QString path)
{
    if (mQMovie)
        delete mQMovie;
    mQMovie = new QMovie(path);
    mQMovie->start();
}

void zombie::setHead(QString path)
{
    if (mhead)
        delete mhead;
    mhead = new QMovie(path);
    mhead->start();
}

int zombie::type() const
{
    return Type;
}
zombie::Affix zombie::parseAffix(const QString& affixStr)
{
    if (affixStr == "Speed") {
        return Speed;
    } else if (affixStr == "Flash") {
        return Flash;
    } else {
        return None;
    }
}
void zombie::drawHealthBar(QPainter *painter)
{
    if (maxHp <= 0)
        return;
    int barWidth = 70;
    int barHeight = 10;
    int barX = -20;
    int barY = -100;

    double healthPercentage = static_cast<double>(hp) / maxHp;
    if(hp<=0) {healthPercentage=0;hp=0;}
    int healthBarWidth = static_cast<int>(barWidth * healthPercentage);

    // Draw the background of the health bar
    if(isBleed) painter->setBrush(Qt::blue);
    else painter->setBrush(Qt::red);
    painter->drawRect(barX, barY, barWidth, barHeight);
    // Draw the foreground of the health bar
    painter->setBrush(Qt::green);
    painter->drawRect(barX, barY, healthBarWidth, barHeight);
}
