#include "peashot.h"
#include "zombie.h"
#include<cmath>
peashot::peashot(int attack, bool flag,bool Bleed, int dir,qreal x,qreal y)
{
    atk = attack; // Set the attack power of the pea shooter
    snow = flag; // Set the flag indicating whether it has a freezing effect
    isBleed = Bleed;
    speed = 360.0 * 33 / 1000; // Set the speed of the pea shooter (360 pixels per second)
    direction = dir; // Set the direction of movement
    shoot_x=x;
    shoot_y=y;

}

QRectF peashot::boundingRect() const
{
    // Set the bounding rectangle of the pea shooter
    return QRectF(-12, -28, 24, 24); // Top-left corner coordinates (-12, -28), width 24, height 24
}

bool peashot::collidesWithItem(const QGraphicsItem *other, Qt::ItemSelectionMode mode) const
{
    Q_UNUSED(mode)
    // Return true when the pea shooter collides with a zombie
    return other->type() == zombie::Type && qAbs(other->y() - y()) < 58 && qAbs(other->x() - x()) < 58;
}

void peashot::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option)
    Q_UNUSED(widget)
    // Draw the image of the pea shooter, choose different images based on whether it has a freezing effect
    painter->drawPixmap(QRect(-12, -28, 24, 24), QPixmap(snow ? ":/Bullets/res/Bullets/PeaIce/PeaIce_0.png" : ":/Bullets/res/Bullets/PeaNormal/PeaNormal_0.png"));
}
void peashot::advance(int phase)
{
    if (!phase)
        return;
    update(); // Update the drawing of the pea shooter

    // Check if the pea shooter collides with other objects
    QList<QGraphicsItem *> items = collidingItems();

    if (!items.isEmpty())
    {

        // When the pea shooter collides with a zombie
        zombie *zom = qgraphicsitem_cast<zombie *>(items[0]);
        zom->hp -= atk; // Reduce the health of the zombie by the attack power of the pea shooter
        qDebug()<<"zom hurt"<<zom->hp;
        // If the pea shooter has a freezing effect and the zombie's speed is greater than half of its initial speed
        //if (snow && zom->speed > 5.0 * 33 / 1000 / 2)
        if (snow)
        {
            //zom->speed /= 3; // Reduce the speed of the zombie to one-third of its original speed
            zom->isFrozen=true;
        }
        if(isBleed){
            zom->isBleed=true;
            zom->bleedTimer.restart();
        }

        delete this; // Delete the pea shooter object
        return;
    }
    double zx=shoot_x;
    double zy=shoot_y;
    double deltaX = std::abs(zx - x());
    double deltaY = std::abs(zy - y());
    double hypotenuse = std::sqrt(deltaX * deltaX + deltaY * deltaY);
    double cos_theta = deltaX / hypotenuse;
    double sin_theta = deltaY / hypotenuse;
    //qDebug()<<zx<<x()<<deltaX<<deltaY <<hypotenuse<<cos_theta<<sin_theta;
    setX(x() + speed * cos_theta); // Update the position of the pea shooter, moving it forward
    setY(y() + direction * speed * sin_theta); // Update the vertical position of the pea shooter for diagonal movement

    // If the position of the pea shooter exceeds the screen boundary (x > 1069), delete the pea shooter object
    if (x() > 1090||x()<=0)
        delete this;
}

